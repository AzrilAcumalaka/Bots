const chalk = require("chalk")
const fs = require("fs")

  global.ownerNumber = "6285810632092@s.whatsapp.net"
  global.kontakOwner = "6285810632092"
  global.namaStore = "MORO || STORE"
  global.botName = "MORO || BOT"
  global.ownerName = "Hairi"
  
  
  global.linkyt = "https://youtube.com/@moro_miniworld?si=5aYdmm7rrm5XGXMn"
  global.linkig = "https://www.instagram.com/moro_0id?igsh=MXZ4N3J0bnAzeTFmdQ==" 
  global.dana = "6285810632092" 
  global.ovo = "6285810632092"
  global.gopay = "6285810632092" 
  global.sawer = "https://saweria.co/OCEANminiworld" 
 global.linkgc1 = "--"
 global.linkgc2 = "--"
//Jikalau dari salah satu di atas kalian tidak memiliki 
//silahkan kosongkan atau isi --


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})